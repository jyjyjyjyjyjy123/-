package com.project.apa.auth.repository;


import com.project.apa.auth.model.MemberDTO;

public interface AuthDAO {

	String getuserseq(String userid);
}
