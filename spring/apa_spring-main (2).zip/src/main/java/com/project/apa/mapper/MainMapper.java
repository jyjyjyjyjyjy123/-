package com.project.apa.mapper;

public interface MainMapper {

}
