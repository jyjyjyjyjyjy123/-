package com.test.domain;

import lombok.Data;

@Data
public class SelfsymtomDTO {
	private String selfsymtomseq;
	private String selfsymtomname;
}
