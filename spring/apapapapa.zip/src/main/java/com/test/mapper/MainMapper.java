package com.test.mapper;

public interface MainMapper {

}
