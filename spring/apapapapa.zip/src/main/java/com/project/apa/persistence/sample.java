package com.project.apa.persistence;

public class sample {

}
