package com.project.apa.api.advice.domain;

import lombok.Data;

@Data
public class StorageDTO {
	
	private String userSeq;
	private String medicounselanswerseq;
	
	private String mediCounselBoxSeq;
}
