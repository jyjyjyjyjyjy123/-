package com.project.apa.api.search.model;

import lombok.Data;

@Data
public class BookMarkDTO {
	private String bookmarkseq;
	private String hospitalid;
	private String userseq;
}
