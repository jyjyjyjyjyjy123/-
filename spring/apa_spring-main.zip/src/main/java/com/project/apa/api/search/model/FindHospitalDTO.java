package com.project.apa.api.search.model;

import lombok.Data;

@Data
public class FindHospitalDTO {
	private String seq1;
	private String seq2;
	private String seq3;
	private String seq4;
	private String seq5;
	private String seq6;
	private String seq7;
	private String seq8;
	private String deptseq;
}
