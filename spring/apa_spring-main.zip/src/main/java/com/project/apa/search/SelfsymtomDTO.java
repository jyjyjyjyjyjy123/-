package com.project.apa.search;

import lombok.Data;

@Data
public class SelfsymtomDTO {
	private String selfsymtomseq;
	private String selfsymtomname;
}
