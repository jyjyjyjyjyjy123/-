package com.project.apa.api.search.model;

import lombok.Data;

@Data
public class SelfsymtomDTO {
	private String selfsymtomseq;
	private String selfsymtomname;
	
	private String diseasename;
	private String departmentseq;
	private String departmentname;	
}
