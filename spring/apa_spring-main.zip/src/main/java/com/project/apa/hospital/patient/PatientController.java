package com.project.apa.hospital.patient;

public class PatientController {

}
