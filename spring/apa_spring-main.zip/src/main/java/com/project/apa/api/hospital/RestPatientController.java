package com.project.apa.api.hospital;

public class RestPatientController {

}
