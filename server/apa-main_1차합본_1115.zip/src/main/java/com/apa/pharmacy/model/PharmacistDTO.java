package com.apa.pharmacy.model;

public class PharmacistDTO {
	
	private String pharmacistSeq;
	private String pharmacyId;
	private String pharmacistName;
	public String getPharmacistSeq() {
		return pharmacistSeq;
	}
	public void setPharmacistSeq(String pharmacistSeq) {
		this.pharmacistSeq = pharmacistSeq;
	}
	public String getPharmacyId() {
		return pharmacyId;
	}
	public void setPharmacyId(String pharmacyId) {
		this.pharmacyId = pharmacyId;
	}
	public String getPharmacistName() {
		return pharmacistName;
	}
	public void setPharmacistName(String pharmacistName) {
		this.pharmacistName = pharmacistName;
	}
	
	
}
