package com.apa.pharmacy.model;


public class DispenseCntDTO {
	
	private String watingCnt;
	private String jejoCnt;
	private String jejoFinCnt;
	private String surungFinCnt;
	private String totalCnt;
	public String getWatingCnt() {
		return watingCnt;
	}
	public void setWatingCnt(String watingCnt) {
		this.watingCnt = watingCnt;
	}
	public String getJejoCnt() {
		return jejoCnt;
	}
	public void setJejoCnt(String jejoCnt) {
		this.jejoCnt = jejoCnt;
	}
	public String getJejoFinCnt() {
		return jejoFinCnt;
	}
	public void setJejoFinCnt(String jejoFinCnt) {
		this.jejoFinCnt = jejoFinCnt;
	}
	public String getSurungFinCnt() {
		return surungFinCnt;
	}
	public void setSurungFinCnt(String surungFinCnt) {
		this.surungFinCnt = surungFinCnt;
	}
	public String getTotalCnt() {
		return totalCnt;
	}
	public void setTotalCnt(String totalCnt) {
		this.totalCnt = totalCnt;
	}
	
	
	
}



