package com.apa.admin.advice;

public class adminAdviceDTO {

	private String adviceSeq;
	private String departSeq;
	private String adviceTitle;
	private String adviceContent;
	private String departName;
	private String isAnswer;
	private String adviceHospitalName;
	private String adviceDoctorName;
	private String adviceCounselAnswerContent;
	private String doctorDepartment;
	private String userId;
	private String userSeq;
	private String adviceRegdate;
	
	
	
	public String getAdviceRegdate() {
		return adviceRegdate;
	}
	public void setAdviceRegdate(String adviceRegdate) {
		this.adviceRegdate = adviceRegdate;
	}
	public String getUserSeq() {
		return userSeq;
	}
	public void setUserSeq(String userSeq) {
		this.userSeq = userSeq;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getDoctorDepartment() {
		return doctorDepartment;
	}
	public void setDoctorDepartment(String doctorDepartment) {
		this.doctorDepartment = doctorDepartment;
	}
	public String getAdviceSeq() {
		return adviceSeq;
	}
	public void setAdviceSeq(String adviceSeq) {
		this.adviceSeq = adviceSeq;
	}
	public String getDepartSeq() {
		return departSeq;
	}
	public void setDepartSeq(String departSeq) {
		this.departSeq = departSeq;
	}
	public String getAdviceTitle() {
		return adviceTitle;
	}
	public void setAdviceTitle(String adviceTitle) {
		this.adviceTitle = adviceTitle;
	}
	public String getAdviceContent() {
		return adviceContent;
	}
	public void setAdviceContent(String adviceContent) {
		this.adviceContent = adviceContent;
	}
	public String getDepartName() {
		return departName;
	}
	public void setDepartName(String departName) {
		this.departName = departName;
	}
	public String getIsAnswer() {
		return isAnswer;
	}
	public void setIsAnswer(String isAnswer) {
		this.isAnswer = isAnswer;
	}
	public String getAdviceHospitalName() {
		return adviceHospitalName;
	}
	public void setAdviceHospitalName(String adviceHospitalName) {
		this.adviceHospitalName = adviceHospitalName;
	}
	public String getAdviceDoctorName() {
		return adviceDoctorName;
	}
	public void setAdviceDoctorName(String adviceDoctorName) {
		this.adviceDoctorName = adviceDoctorName;
	}
	public String getAdviceCounselAnswerContent() {
		return adviceCounselAnswerContent;
	}
	public void setAdviceCounselAnswerContent(String adviceCounselAnswerContent) {
		this.adviceCounselAnswerContent = adviceCounselAnswerContent;
	}
	
	
	
	
	

}
