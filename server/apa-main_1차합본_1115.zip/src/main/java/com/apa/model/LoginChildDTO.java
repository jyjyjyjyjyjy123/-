package com.apa.model;

import lombok.Data;

@Data
public class LoginChildDTO {
    private String childSeq;
    private String userSeq;
    private String childName;
    private String childSsn;
    private String childTel;

}
