package com.apa.repository;

import com.apa.DBUtil;
import com.apa.model.PharmacyInfoDTO;
import com.apa.model.UserDTO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class UserDAO {

    private Connection conn;
    private Statement stat;
    private PreparedStatement pstat;
    private ResultSet rs;

    public UserDAO() {
        this.conn = DBUtil.open();
    }

    public int userRegister(UserDTO dto) {
        try {
            String sql = "insert into tblUser(userseq, username, userssn, userid, userpw, usertel ,useraddress, useremail, userchild, usercautioncount, registerdate, isuserunregister) values (SEQUSER.nextval,?, ? , ?, ?, ?, ? , ?, ?, default, default, default)";



            pstat = conn.prepareStatement(sql);
            pstat.setString(1, dto.getUserName());
            pstat.setString(2, dto.getUserSsn());
            pstat.setString(3, dto.getUserId());
            pstat.setString(4, dto.getUserPw());
            pstat.setString(5, dto.getUserTel());
            pstat.setString(6, dto.getUserAddress());
            pstat.setString(7, dto.getUserEmail());
            pstat.setString(8, dto.getUserChild());

            return pstat.executeUpdate();

        } catch (Exception e) {
            System.out.println(" ");
            e.printStackTrace();
        }

        return 0;
    }

    public UserDTO login(UserDTO dto) {
            try {
                System.out.println(dto.getUserId());

                String sql = "select * from tblUser where UserId = ? and USerPw = ? and ISUSERUNREGISTER = 'n'";

                pstat = conn.prepareStatement(sql);
                pstat.setString(1, dto.getUserId());
                pstat.setString(2, dto.getUserPw());

                rs = pstat.executeQuery();

                if (rs.next()) {

                    UserDTO result = new UserDTO();

                    result.setUserId(rs.getString("userId"));
                    result.setUserName(rs.getString("userName"));

                    return result;
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;

        }

	public ArrayList<PharmacyInfoDTO> pharmacylist() {
		try {
			
			String sql = "select * from vwPharmacyInfo";
			
			stat = conn.createStatement();
			rs = stat.executeQuery(sql);
			
			ArrayList<PharmacyInfoDTO> list = new ArrayList<PharmacyInfoDTO>();
			
			while (rs.next()) {
				
				PharmacyInfoDTO dto = new PharmacyInfoDTO();
				
				dto.setId(rs.getString("PHARMACYID"));
				dto.setName(rs.getString("PHARMACYNAME"));
				dto.setAddress(rs.getString("PHARMACYADDRESS"));
				dto.setEmail(rs.getString("PHARMACYEMAIL"));
				dto.setTel(rs.getString("PHARMACYTEL"));
				dto.setDispense(rs.getString("ISDISPENSE"));
				dto.setOpen(rs.getString("ISPHARMACY"));
				dto.setNight(rs.getString("ISPHARMARCYNIGHTCARE"));
				dto.setHoliday(rs.getString("ISPHARMARCYHOLIDAY"));
				dto.setDayoff(rs.getString("PHARMACYDAYOFF"));
				dto.setOpentime(rs.getString("OPENTIME"));
				dto.setClosetime(rs.getString("CLOSETIME"));
				
				list.add(dto);
				
			}
			
			return list;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}



}