package com.apa.user;

import com.apa.model.UserDTO;
import com.apa.repository.UserDAO;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/user/login.do")
public class Login extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/user/login.jsp");
		dispatcher.forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String userid = req.getParameter("id");
		String userpw = req.getParameter("pw");

		UserDAO dao = new UserDAO();

		UserDTO dto = new UserDTO();
		dto.setUserId(userid);
		dto.setUserPw(userpw);

		UserDTO result = dao.login(dto);

		if(result != null){
			req.getSession().setAttribute("id", userid);
			req.getSession().setAttribute("userName", result.getUserName());
//			req.getSession().setAttribute("lv", result.());

			resp.sendRedirect("/main.do");
		}else{
			PrintWriter writer = resp.getWriter();
			writer.print("<script>alert('failed');history.back();</script>");
			writer.close();
		}
	}
}

