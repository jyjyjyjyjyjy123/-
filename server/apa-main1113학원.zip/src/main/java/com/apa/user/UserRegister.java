package com.apa.user;

import com.apa.model.UserDTO;
import com.apa.repository.UserDAO;
import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Member;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/user/userregister.do")
public class UserRegister extends HttpServlet {


	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/user/userregister.jsp");
		dispatcher.forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {


		try{

			String userId = req.getParameter("id");
			String userPw = req.getParameter("pw");
			String userName = req.getParameter("name");
			String userSsn = req.getParameter("ssn");
			String userTel = req.getParameter("tel");
			String userChild = req.getParameter("child");
			String userEmail = req.getParameter("email");
			String userAddress = req.getParameter("address");

			UserDTO dto = new UserDTO();
			UserDAO dao = new UserDAO();

			dto.setUserId(userId);
			dto.setUserPw(userPw);
			dto.setUserName(userName);
			dto.setUserSsn(userSsn);
			dto.setUserTel(userTel);
			dto.setUserChild(userChild);
			dto.setUserEmail(userEmail);
			dto.setUserAddress(userAddress);


			int result = dao.userRegister(dto);

			if(result == 1){

				resp.sendRedirect("/main.do");
			}
		} catch (Exception e) {
			System.out.println("UserRegister.doPost()");
			e.printStackTrace();
		}
		//0또는 에러
		PrintWriter writer = resp.getWriter();
		writer.print("<script>alert('failed');history.back();</script>");
		writer.close();
	}
}

