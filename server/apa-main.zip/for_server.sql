select count(*) from tblHoliday; --55개

select count(*) from tblMediTest; --8개

select count(*) from tblMediTestQuestion; --85개

select count(*) from tblMediTestAnswer; --289개

select count(*) from tblMediTestResult; --25개

select count(*) from tblTag; --13개

select count(*) from tblAdmin; -- 1개

select count(*) from tblWikiList; -- 204개

select count(*) from tblNotice; -- 89개

select count(*) from TBLONLINEFORMQUESTION; -- 20개

select count(*) from TBLONLINEFORMANSWER; --100개

select count(*) from tblDepartment; --21개 체크

select count(*) from tblHospital; --150개

select count(*) from tblDoctor; --252개

select count(*) from tblHeadDoctor; --150개

select count(*) from tblHospitalOperation; --150개

select count(*) from tblRestTime; --150개

select count(*) from tblHospitalDayOff; --199개

select count(*) from tblHospitalTreatment; --299개

select count(*) from TBLUSER; --300개

select count(*) from TBLCHILD; --52개 체크

select count(*) from TBLBLACKLIST; --50개

select count(*) from TBLHEALTHCARE; --227개

select count(*) from TBLSELFSYMTOM; --119개

select count(*) from TBLDIAGNOSISDISEASE; --53개

select count(*) from tblMediTestSave; --48개

select count(*) from TBLMEDICOUNSELINGQUESTION; --100개 

select count(*) from TBLMEDICOUNSELINGANSWER; --70개

select count(*) from TBLMEDICOUNSELINGBOX; --50개

select count(*) from tblBookmark;   --100개

select count(*) from tblMediCheckupReservation;    --120개

select count(*) from TBLCHECKUPWAITING; --120개 

select count(*) from tblPharmacy;   --105개

select count(*) from tblPharmacist; --157개

select count(*) from tblPharmacyDayOff;  --88개

select count(*) from tblPharmacyOperation;  --105개

select count(*) from tblDispense;   --202개

select count(*) from tblEntry;  --255개

select count(*) from tblOperatingTime; --255개

select count(*) from tblOnlineFormResult;   -- 1000개

select count(*) from tblRegister;   --410개 

select count(*) from tblWatingPatientList; --405개

select count(*) from tblMediHistory;       --368개

select count(*) from tblRequestDocument;   --100개

select count(*) from tblReview;        --160개

select count(*) from tblReviewTag;     --800개

select count(*) from tblCommunity; --244개

select count(*) from TBLREPORTBOX; --167개

select count(*) from tblCommunityBox;  --244개

select count(*) from TBLMAGAZINE;  --200개


commit;

