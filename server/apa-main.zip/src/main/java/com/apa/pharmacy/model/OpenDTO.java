package com.apa.pharmacy.model;


public class OpenDTO {
	
	private String pharmacyId;
	private String pharmacyName;
	private String openTime;
	private String closeTime;
	private String pharmacyDayOff;
	private String isPharmarcyNightCare;
	private String isPharmarcyHoliday;
	
	public String getPharmacyId() {
		return pharmacyId;
	}
	public void setPharmacyId(String pharmacyId) {
		this.pharmacyId = pharmacyId;
	}
	public String getOpenTime() {
		return openTime;
	}
	public void setOpenTime(String openTime) {
		this.openTime = openTime;
	}
	public String getCloseTime() {
		return closeTime;
	}
	public void setCloseTime(String closeTime) {
		this.closeTime = closeTime;
	}
	public String getPharmacyDayOff() {
		return pharmacyDayOff;
	}
	public void setPharmacyDayOff(String pharmacyDayOff) {
		this.pharmacyDayOff = pharmacyDayOff;
	}
	public String getIsPharmarcyNightCare() {
		return isPharmarcyNightCare;
	}
	public void setIsPharmarcyNightCare(String isPharmarcyNightCare) {
		this.isPharmarcyNightCare = isPharmarcyNightCare;
	}
	public String getIsPharmarcyHoliday() {
		return isPharmarcyHoliday;
	}
	public void setIsPharmarcyHoliday(String isPharmarcyHoliday) {
		this.isPharmarcyHoliday = isPharmarcyHoliday;
	}
	public String getPharmacyName() {
		return pharmacyName;
	}
	public void setPharmacyName(String pharmacyName) {
		this.pharmacyName = pharmacyName;
	}
	
	
	
	
	
	
	
	
	
}
