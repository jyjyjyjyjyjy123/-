package com.apa.model;

public class UserChildDTO {
	private String userChild;
	private String childSeq;
	private String childName;
	private String childSsn;
	private String childTel;
	
	public String getUserChild() {
		return userChild;
	}
	public void setUserChild(String userChild) {
		this.userChild = userChild;
	}
	public String getChildSeq() {
		return childSeq;
	}
	public void setChildSeq(String childSeq) {
		this.childSeq = childSeq;
	}
	public String getChildName() {
		return childName;
	}
	public void setChildName(String childName) {
		this.childName = childName;
	}
	public String getChildSsn() {
		return childSsn;
	}
	public void setChildSsn(String childSsn) {
		this.childSsn = childSsn;
	}
	public String getChildTel() {
		return childTel;
	}
	public void setChildTel(String childTel) {
		this.childTel = childTel;
	}
	
}
