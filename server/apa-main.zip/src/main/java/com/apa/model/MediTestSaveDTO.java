package com.apa.model;

public class MediTestSaveDTO {
	
	private String mediTestSaveSeq;
	private String mediTestName;
	private String testTime;
	public String getMediTestSaveSeq() {
		return mediTestSaveSeq;
	}
	public void setMediTestSaveSeq(String mediTestSaveSeq) {
		this.mediTestSaveSeq = mediTestSaveSeq;
	}
	public String getMediTestName() {
		return mediTestName;
	}
	public void setMediTestName(String mediTestName) {
		this.mediTestName = mediTestName;
	}
	public String getTestTime() {
		return testTime;
	}
	public void setTestTime(String testTime) {
		this.testTime = testTime;
	}
	
	
}
