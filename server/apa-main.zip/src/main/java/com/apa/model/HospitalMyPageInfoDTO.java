package com.apa.model;

public class HospitalMyPageInfoDTO {
	private String hospitalSeq;
	private String hospitalName;
	private String hospitalId;
	private String hospitalPw;
	private String hospitalSsn;
	private String hospitalTel;
	private String hospitalEmail;
	private String hospitalAddress;
	
	private String hospitalSSNs;
	private String hospitalSSNm;
	private String hospitalSSNe;

	private String hospitalTels;
	private String hospitalTelm;
	private String hospitalTele;
	
	
	
	
	public String getHospitalSSNm() {
		return hospitalSSNm;
	}
	public void setHospitalSSNm(String hospitalSSNm) {
		this.hospitalSSNm = hospitalSSNm;
	}
	public String getHospitalSeq() {
		return hospitalSeq;
	}
	public void setHospitalSeq(String hospitalSeq) {
		this.hospitalSeq = hospitalSeq;
	}
	public String getHospitalName() {
		return hospitalName;
	}
	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}
	public String getHospitalId() {
		return hospitalId;
	}
	public void setHospitalId(String hospitalId) {
		this.hospitalId = hospitalId;
	}
	public String getHospitalPw() {
		return hospitalPw;
	}
	public void setHospitalPw(String hospitalPw) {
		this.hospitalPw = hospitalPw;
	}
	public String getHospitalSsn() {
		return hospitalSsn;
	}
	public void setHospitalSsn(String hospitalSsn) {
		this.hospitalSsn = hospitalSsn;
	}
	public String getHospitalTel() {
		return hospitalTel;
	}
	public void setHospitalTel(String hospitalTel) {
		this.hospitalTel = hospitalTel;
	}
	public String getHospitalEmail() {
		return hospitalEmail;
	}
	public void setHospitalEmail(String hospitalEmail) {
		this.hospitalEmail = hospitalEmail;
	}
	public String getHospitalAddress() {
		return hospitalAddress;
	}
	public void setHospitalAddress(String hospitalAddress) {
		this.hospitalAddress = hospitalAddress;
	}
	public String getHospitalSSNs() {
		return hospitalSSNs;
	}
	public void setHospitalSSNs(String hospitalSSNs) {
		this.hospitalSSNs = hospitalSSNs;
	}
	public String getHospitalSSNe() {
		return hospitalSSNe;
	}
	public void setHospitalSSNe(String hospitalSSNe) {
		this.hospitalSSNe = hospitalSSNe;
	}
	public String getHospitalTels() {
		return hospitalTels;
	}
	public void setHospitalTels(String hospitalTels) {
		this.hospitalTels = hospitalTels;
	}
	public String getHospitalTelm() {
		return hospitalTelm;
	}
	public void setHospitalTelm(String hospitalTelm) {
		this.hospitalTelm = hospitalTelm;
	}
	public String getHospitalTele() {
		return hospitalTele;
	}
	public void setHospitalTele(String hospitalTele) {
		this.hospitalTele = hospitalTele;
	}
	
	
}
