package com.apa.model;

public class CommunityStorageDTO {
	private String communitySeq;
	private String communityTitle;
	private String communityCommentCount;
	private String communityLikeCount;
	private String communityDate;
	public String getCommunitySeq() {
		return communitySeq;
	}
	public void setCommunitySeq(String communitySeq) {
		this.communitySeq = communitySeq;
	}
	public String getCommunityTitle() {
		return communityTitle;
	}
	public void setCommunityTitle(String communityTitle) {
		this.communityTitle = communityTitle;
	}
	public String getCommunityCommentCount() {
		return communityCommentCount;
	}
	public void setCommunityCommentCount(String communityCommentCount) {
		this.communityCommentCount = communityCommentCount;
	}
	public String getCommunityLikeCount() {
		return communityLikeCount;
	}
	public void setCommunityLikeCount(String communityLikeCount) {
		this.communityLikeCount = communityLikeCount;
	}
	public String getCommunityDate() {
		return communityDate;
	}
	public void setCommunityDate(String communityDate) {
		this.communityDate = communityDate;
	}
	
}
