package com.apa.model;

public class ChildrenDTO {

	private String childSeq;
	private String userSeq;
	private String childName;
	private String childSSN;
	private String childTel;
	private String userChild;
	
	public String getUserChild() {
		return userChild;
	}
	public void setUserChild(String userChild) {
		this.userChild = userChild;
	}
	public String getChildSeq() {
		return childSeq;
	}
	public void setChildSeq(String childSeq) {
		this.childSeq = childSeq;
	}
	public String getUserSeq() {
		return userSeq;
	}
	public void setUserSeq(String userSeq) {
		this.userSeq = userSeq;
	}
	public String getChildName() {
		return childName;
	}
	public void setChildName(String childName) {
		this.childName = childName;
	}
	public String getChildSSN() {
		return childSSN;
	}
	public void setChildSSN(String childSSN) {
		this.childSSN = childSSN;
	}
	public String getChildTel() {
		return childTel;
	}
	public void setChildTel(String childTel) {
		this.childTel = childTel;
	}
	
	
}
