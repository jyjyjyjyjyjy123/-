package com.apa.model;

import lombok.Data;

public class UserDTO {
    private int userSeq;
    private String userSeq2;
    private String userName;
    private String userSsn;
    private String userId;
    private String userPw;
    private String userTel;
    private String userAddress;
    private String userEmail;
    private String userChild;
    private String userCautionCount;
    private String registerDate;
    private String isUserUnregister;
    
	private String userSSNs;
	private String userSSNe;

	private String userTels;
	private String userTelm;
	private String userTele;
	
	
	public String getUserSSNs() {
		return userSSNs;
	}
	public void setUserSSNs(String userSSNs) {
		this.userSSNs = userSSNs;
	}
	public String getUserSSNe() {
		return userSSNe;
	}
	public void setUserSSNe(String userSSNe) {
		this.userSSNe = userSSNe;
	}
	public String getUserTels() {
		return userTels;
	}
	public void setUserTels(String userTels) {
		this.userTels = userTels;
	}
	public String getUserTelm() {
		return userTelm;
	}
	public void setUserTelm(String userTelm) {
		this.userTelm = userTelm;
	}
	public String getUserTele() {
		return userTele;
	}
	public void setUserTele(String userTele) {
		this.userTele = userTele;
	}
	public int getUserSeq() {
		return userSeq;
	}
	public void setUserSeq(int userSeq) {
		this.userSeq = userSeq;
	}
	public String getUserSeq2() {
		return userSeq2;
	}
	public void setUserSeq2(String userSeq2) {
		this.userSeq2 = userSeq2;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserSsn() {
		return userSsn;
	}
	public void setUserSsn(String userSsn) {
		this.userSsn = userSsn;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserPw() {
		return userPw;
	}
	public void setUserPw(String userPw) {
		this.userPw = userPw;
	}
	public String getUserTel() {
		return userTel;
	}
	public void setUserTel(String userTel) {
		this.userTel = userTel;
	}
	public String getUserAddress() {
		return userAddress;
	}
	public void setUserAddress(String userAddress) {
		this.userAddress = userAddress;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getUserChild() {
		return userChild;
	}
	public void setUserChild(String userChild) {
		this.userChild = userChild;
	}
	public String getUserCautionCount() {
		return userCautionCount;
	}
	public void setUserCautionCount(String userCautionCount) {
		this.userCautionCount = userCautionCount;
	}
	public String getRegisterDate() {
		return registerDate;
	}
	public void setRegisterDate(String registerDate) {
		this.registerDate = registerDate;
	}
	public String getIsUserUnregister() {
		return isUserUnregister;
	}
	public void setIsUserUnregister(String isUserUnregister) {
		this.isUserUnregister = isUserUnregister;
	}
    
    
    
    
    
    
    
    


}
